import React,{useState,useEffect} from'react'
function Userproduct(){
    const[product,setProduct]=useState([])
    useEffect(()=>{
        const storedproduct=JSON.parse(localStorage.getItem('products'))||[]
        setProduct(storedproduct)
    },[])
    const addtocart=(product)=>{
        let cart=JSON.parse(localStorage.getItem('cart'))||[]
        cart.push(product)
        localStorage.setItem('cart',JSON.stringify(cart))
        alter('product added to cart')
    }
    return(
        <div>
            {product.length===0?(
                <p>No product found</p>

            ):(
                product.map((item,index)=>(
                    <div key={index}>
                    <h3>{item.name}</h3>
                    <h3>{item.price}</h3>
                    <button onClick={()=>addtocart(item)}>Add to cart</button>
                    
                      </div>
                ))
            )}
        </div>
    )
}
export default Userproduct