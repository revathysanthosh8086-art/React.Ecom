import React, { useState, useEffect } from 'react'

function Product() {
  const [product, setProduct] = useState("")
  const [price, setPrice] = useState("")
  const [items, setItems] = useState([])

  
  useEffect(() => {
    const data = JSON.parse(localStorage.getItem('products')) || []
    setItems(data)
  }, [])

  const handleAdd = () => {
    if (!product || !price) {
      alert("Enter product and price");
      return;
    }

    const newItem = { product, price }

    const oldData = JSON.parse(localStorage.getItem('products')) || []
    const updatedData = [...oldData, newItem]

    localStorage.setItem('products', JSON.stringify(updatedData))
    setItems(updatedData)

    setProduct("")
    setPrice("")
  }

  return (
    <div>
      <h2>Admin Product Page</h2>
      <input
        type="text"
        placeholder="Enter Product"
        value={product}
        onChange={(e) => setProduct(e.target.value)}
      />
      <br /><br />

      <input
        type="number"
        placeholder="Enter Price"
        value={price}
        onChange={(e) => setPrice(e.target.value)}
      />
      <br /><br />

      <button onClick={handleAdd}>Add Product</button>

      <hr />

    
      <h3>Product List</h3>

      <table border="1">
        <tr>
          <th>Product</th>
          <th>Price</th>
        </tr>

        {items.map((item, index) => (
          <tr key={index}>
            <td>{item.product}</td>
            <td>{item.price}</td>
          </tr>
        ))}
      </table>
    </div>
  );
}

export default Product