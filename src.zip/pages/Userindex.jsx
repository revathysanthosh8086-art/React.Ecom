import React from 'react'
function UserIndex()
{
    return(
        <div>
            <h1>User Page</h1>
        </div>
    )
}
export default UserIndex