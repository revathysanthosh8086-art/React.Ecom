import React,{useState,useEffect} from 'react'
function Cart(){
    const[cartItem,setCartItem]= useState([])
    useEffect(()=>{
        const storedcart=
        JSON.parse(localStorage.getItem('cart'))||[]
        setCartItem(storedcart)
    },[])
    return(
        <div>
            {cartItem.length===0?(
                <p>No product found</p>

            ):(
                cartItem.map((item,index)=>(
                    <div key={index}>
                    <h3>{item.name}</h3>
                    <h3>{item.price}</h3>
                    <button>Remove from cart</button>
                    
                      </div>
                ))
            )}
        </div>
    )
}
export default Cart