import React from 'react'
import { useNavigate } from 'react-router-dom'
function AdminNavbar() {
    const navigate=useNavigate()
    const handleLogout = () => {
        localStorage.removeItem('Role')
        localStorage.removeItem('loggeduser')
        navigate('/login')
    }
    return (
        <div>
            <nav>
                 <a href="/">Home</a> {" "}
                <a href="/Users">Users</a> {" "}
                <a href="/orders">Orders</a> {" "}
                <a href="/product">Product</a>{""}
                <button onClick={handleLogout}>Logout</button>

            </nav>
         </div>
    )
}

export default AdminNavbar