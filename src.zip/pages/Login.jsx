import React, { useState } from "react";
import {useNavigate} from 'react-router-dom'
function Login() {
  const [user, setUser] = useState({email: '',password: ''});
  const navigate=useNavigate()

  const handlechange = (e) => {setUser({...user,[e.target.name]: e.target.value});
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!user.email || !user.password) {
      alert("All fields are required");
      return;
    }

    let users = JSON.parse(localStorage.getItem('users')) || [];

    const exist = users.find(
      (i) =>
        i.email === user.email &&
        i.password === user.password
    );

    const adminmail='admin@gmail.com'
    const adminpass='admin'
    if(user.email===adminmail && user.password===adminpass){
      localStorage.setItem('Role','Admin')
      alert('Admin Login Successful')
      navigate('/admin')
      window.location.reload()
     
      return
    }
    

    if (exist) {
      localStorage.setItem('loggeduser',JSON.stringify(user))
      localStorage.setItem('Role','User')
      alert("Login Successful");
      navigate('/user')
      window.location.reload()
      
    } else {
      alert("Invalid Email or Password");
      navigate('/Registration')
    }

    setUser({email: '',password: ''});
  };

  return (
    <div>
      <h2>Login Form</h2>

      <form onSubmit={handleSubmit}>
        <input type="email" name="email" placeholder="Enter Email" value={user.email} onChange={handlechange} />
        <br /><br />

        <input type="password" name="password" placeholder="Enter Password" value={user.password} onChange={handlechange}/>
        <br /><br />

        <button type="submit">Login</button>
      </form>
    </div>
  );
}

export default Login;

