import React, { useState, useEffect } from 'react'
import Product from './AdminProduct'

function Users() {
    const [data, setData] = useState([])

    useEffect(() => {
        let users = JSON.parse(localStorage.getItem('Users')) || []
        setData(users)
    }, [])

    return (
        <div>

            <h2>User List</h2>

            <table border="1">

                <thead>
                    <tr>
                        <th>No</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Password</th>
                    </tr>
                </thead>

                <body>
                    {data.map((item, index) => (
                        <tr key={index}>
                            <td>{index + 1}</td>
                            <td>{item.name}</td>
                            <td>{item.email}</td>
                            <td>{item.password}</td>
                        </tr>
                    ))}
                </body>

            </table>

        </div>
    )
}

export default Users