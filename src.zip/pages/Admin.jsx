// import React, { useEffect, useState } from 'react'

// function Admin() {
//   const [users, setUsers] = useState([]);

//   useEffect(() => {
//     const data = JSON.parse(localStorage.getItem("users")) || [];
//     setUsers(data);
//   }, []);

//   return (
//     <div>
//       <h2>Admin Page</h2>

//       <table border="1">
//         <tr>
//           <th>Name</th>
//           <th>Email</th>
//           <th>Password</th>
//         </tr>

//         {users.map((user, index) => (
//           <tr key={index}>
//             <td>{user.name}</td>
//             <td>{user.email}</td>
//             <td>{user.password}</td>
//           </tr>
//         ))}
//       </table>
//     </div>
//   );
// }

// export default Admin;

import React from 'react'
function Admin(){
    return(
        <div>
            <h1>Admin Home</h1>
        </div>
    )
}
export default Admin