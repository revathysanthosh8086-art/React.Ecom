import React from 'react'
import { useNavigate } from 'react-router-dom'
function UserNavbar() {
    const navigate=useNavigate()
    const handleLogout=()=>{
        localStorage.removeItem('Role')
        localStorage.removeItem('loggeduser')
        navigate('/login')
    }
    return (
        <div>
            <nav>
                <a href="/">Home</a> {" "}
                <a href="/cart">Cart</a> {" "}
                <a href="/products">Products</a>
                <button onClick={handleLogout}>Logout</button>
            </nav>

            
        </div>
    )
}

export default UserNavbar