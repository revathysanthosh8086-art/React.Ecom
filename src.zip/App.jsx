import React from 'react'
import Home from './pages/Home'
import Registration from './pages/Registration'
import Login  from './pages/Login'
import UserIndex from './pages/userindex'
import Protect from './pages/Protect'
import Admin from './pages/Admin'
import AdminNavbar from './pages/AdminNavbar'
import UserNavbar from './pages/UserNavbar'
import AdminProduct from './pages/AdminProduct'
import Users from './pages/Users'
import Userproduct from './pages/Userproduct'
import Cart from './pages/Cart'
import{BrowserRouter,Routes,Route,Link} from 'react-router-dom'
function App()
{
  const role=localStorage.getItem('Role')
  return(
    <div>
    <BrowserRouter>
    {role === null && (
        <nav>
          <Link to="/">Home</Link>{" "}
          <Link to="/registration">Registration</Link>{" "}
          <Link to="/login">Login</Link>
          
        </nav>
      )}

      {role === 'Admin' && <AdminNavbar />}

      {role === 'User' && <UserNavbar />}
    <Routes>
      <Route path="/"element={<Home/>}/>
      <Route path="/Registration" element={<Registration/>}/>
      <Route path="/Login" element={<Login/>}/>
      <Route path="/user" element={<Protect><UserIndex/></Protect>}/>
      <Route path="/admin" element={<Admin/>}/>
      <Route path="/product" element={<AdminProduct />} />
      <Route path="/Users" element={<Users/>}/>
      <Route path="/Products" element={<Userproduct/>}/>
      <Route path="/Cart" element={<Cart/>}/>

    </Routes>
    </BrowserRouter>
    </div>
  )
}
export default App