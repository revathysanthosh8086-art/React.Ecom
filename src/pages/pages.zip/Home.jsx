import React from 'react'

function Home() {
  return (
    <div>
    
   <a href="/home">home</a> {""}
   <a href="/product">product</a> {""}
   <a href="/Registration">registration</a> {""}
  <a href="/login">login</a> {""}
  <h1>Home Pages </h1>
  </div>
  )
}

export default Home;

