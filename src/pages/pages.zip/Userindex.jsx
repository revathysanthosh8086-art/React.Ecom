import React from 'react'

function Userindex() {
  return (
  <h1>UserPages </h1>
  )
}

export default Userindex;
