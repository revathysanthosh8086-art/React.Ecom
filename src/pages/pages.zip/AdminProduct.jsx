import React, { useState } from "react";

function AdminProduct() {
  const [product, setProduct] = useState({
    name: "",
    price: ""
  });

  const handleChange = (e) => {
    setProduct({
      ...product,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = () => {
    if (!product.name || !product.price) {
      alert("All fields are required");
      return;
    }

    let products = JSON.parse(localStorage.getItem("products")) || [];

    const exist = products.find((p) => p.name === product.name);

    if (exist) {
      alert("Product already exists");
      return;
    }

    products.push(product);
    localStorage.setItem("products", JSON.stringify(products));

    alert("Product added");

    setProduct({ name: "", price: "" });
  };

  return (
    <div>
      <h2>Add Product</h2>

      <input
        name="name"
        placeholder="Product Name"
        value={product.name}
        onChange={handleChange}
      /><br /><br />

      <input
        name="price"
        placeholder="Price"
        value={product.price}
        onChange={handleChange}
      /><br /><br />

      <button onClick={handleSubmit}>Add Product</button>
    </div>
  );
}

export default AdminProduct;