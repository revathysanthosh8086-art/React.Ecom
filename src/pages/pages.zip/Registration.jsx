// import React,{useState} from "react";

// function Registertion() {
//   const[name,setName]=useState('')
//   const[email,setEmail]=useState('')
//   const[password,setPassword]=useState('')

//   const submit=(e)=>{
//     e.preventDefault()
//     console.log(name,email,password)
//     alert("from submitted")
//   }
//   return (
//     <div>
//       <h2>Registration Form</h2>

//       <form>
//         <input type="text" placeholder="Enter Name" value={name} onChange={(e)=>setName(e.target.value)} />
//         <br /><br />

//         <input type="email" placeholder="Enter Email" value={email} onChange={(e)=>setEmail(e.target.value)} />
//         <br /><br />

//         <input type="password" placeholder="Enter Password" value={password} onChange={(e)=>setPassword(e.target.value)} />
//         <br /><br />

//         <input type="password" placeholder="Confirm Password" value={password} onChange={(e)=>setPassword(e.target.value)} />
//         <br /><br />

//         <button>Register</button>
//       </form>
//     </div>
//   );
// }

// export default Registertion;

import React, { useState } from 'react'
import {useNavigate } from 'react-router-dom'

function Registration() {
  const [user, setUser] = useState({name: '',email: '',password: ''});
const navigate=useNavigate()
  const handlechange = (e) => {
    setUser({...user,[e.target.name]: e.target.value});
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!user.name || !user.email || !user.password) {
      alert('All fields are required');
      return;
    }

    let users = JSON.parse(localStorage.getItem('users')) || []

    const exist = users.find((i) => i.email === user.email);

    if (exist) {
      alert('Email already registered');
      return;
    }

    users.push(user);
    localStorage.setItem('users', JSON.stringify(users));

    alert('Registration complete');
    navigate('/login')

    setUser({ name: '', email: '', password: '' });
  };

  return (
    <div>
      <h2>Registration Form</h2>

      <form onSubmit={handleSubmit}>
        <input type="text" name="name" placeholder="Enter Name" value={user.name} onChange={handlechange}/>
        <br /><br />

        <input type="email" name="email" placeholder="Enter Email" value={user.email} onChange={handlechange} />
        <br /><br />

        <input type="password" name="password" placeholder="Enter Password" value={user.password} onChange={handlechange} />
        <br /><br />

        <button type="submit">Register</button>
      </form>
    </div>
  );
}

export default Registration;