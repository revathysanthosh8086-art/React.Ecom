import React from 'react'

function UserNavbar() {
  return
  <div>
    <nav>
   <a href="/User">home</a> {""}
   <a href="/User">product</a> {""}
  <a href="/User">cart</a> {""}
  </nav>
  </div>
}
 export default UserNavbar;