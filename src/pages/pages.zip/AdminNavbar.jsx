import React from 'react'

function AdminNavbar() {
  return
  <div>
    <nav>
   <a href="/Admin">home</a> {""}
   <a href="/Admin">product</a> {""}
  <a href="/Admin">cart</a> {""}
  <a href="/Admin">order</a> {""}
  </nav>
  </div>
}
 export default AdminNavbar;

